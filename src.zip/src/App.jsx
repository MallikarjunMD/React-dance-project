import React from 'react'
import "./global.css"
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import {ToastContainer} from "react-toastify"
// import "react-toastify/dist/React-Toastify.css" 
import Nav from './components/navbar/Nav'
import Home from "./components/navbar/Home"
import Login from './components/navbar/Login'
import About from './components/navbar/About'
import Register from './components/navbar/Register'
import Pagenotfound from './components/navbar/Pagenotfound'
import Dashboard from './components/admin/Dashboard'
import Addaccmanager from "./components/admin/adminaside/manager/Addaccmanager.jsx"
import Viewaccademy from './components/admin/adminaside/Viewaccademy.jsx'
import Adminregister from './components/navbar/Adminregister'
import Viewmanager from './components/admin/adminaside/Viewmanager.jsx'
import Viewbranch from './components/admin/adminaside/Viewbranch.jsx'
import Viewcourse from './components/admin/adminaside/Viewcourse.jsx'
import Adminprotectedroute from "./serviceroutes/Adminprotectedroute.jsx"

const App = () => {
  return (
    <Router>
      <Nav/>
      <ToastContainer/>
      <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/about' element={<About/>} />
        <Route path='/login' element={<Login/>} />
        <Route path='/register' element={<Register/>} />
        <Route path='/adminregister' element={<Adminregister/>} />
        <Route path='*' element={<Pagenotfound/>}/>

        {/*Admin routes */}
    <Route path='/dashboard' element={<Adminprotectedroute><Dashboard/></Adminprotectedroute>}>
      <Route path='/dashboard/addaccmanager' element={<Addaccmanager/>}/>
      <Route path='/dashboard/viewmanager' element={<Viewmanager/>}/>
      <Route path='/dashboard/viewaccademy' element={<Viewaccademy/>}/>
      <Route path='/dashboard/viewbranch' element={<Viewbranch/>}/>
      <Route path='/dashboard/viewcourse' element={<Viewcourse/>}/>
    </Route>

      </Routes>
    </Router>
    
  )
}

export default App