import React from 'react'

const Viewaccademy = () => {
  return (
    <div>Viewaccademy</div>
  )
}

export default Viewaccademy