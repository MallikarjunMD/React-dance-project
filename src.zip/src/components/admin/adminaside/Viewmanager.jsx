import React from 'react'

const Viewmanager = () => {
  return (
    <div>Viewmanager</div>
  )
}

export default Viewmanager