import React from 'react'

const Viewcourse = () => {
  return (
    <div>Viewcourse</div>
  )
}

export default Viewcourse