import React,{useState} from 'react'
import STYLE from "../manager/addaccmanager.module.css"
import axiosInstance from '../../../../helpers/axiosInstance'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

const Addaccmanager = () => {
  let navigate=useNavigate()
  let token=sessionStorage.getItem("token")
  let[userData,setUserData]=useState({
      userName:"",
      email:"",
      password:"",
      dob:"",
      phone:"",
      gender:""
  })

  let data=(e)=>{
      setUserData({...userData,[e.target.name]:e.target.value})
  }

  let handleRegister=(e)=>{
      e.preventDefault();
      try {
         axiosInstance.post("/academymanagers/save",userData,{
          headers:{
            Authorization: `Bearer ${token}`
          }
         })
         navigate("/login")
         toast.success(`admin ${userData.userName} registered successfully !`) 

      } catch (error) {
          console.log(error);
          alert("Please fill the details properly")
      }
  }

return (
  <div className={STYLE.formholder}>
      <form action="" className={STYLE.form} onSubmit={handleRegister}>
      <h2>Add Academy Manager</h2>
      <div className={STYLE.formitems}>
          <label htmlFor="username">Username</label>
          <input type="text" id='username' name='userName' onChange={data} />
      </div>
      <div className={STYLE.formitems}>
          <label htmlFor="email">Email</label>
          <input type="email" id='email' name='email' onChange={data} />
      </div>
      <div className={STYLE.formitems}>
          <label htmlFor="password">Password</label>
          <input type="password" id='password' name='password' onChange={data} />
      </div>
      <div className={STYLE.formitems}>
          <label htmlFor="phone">Phone</label>
          <input type="number" id='phone' name='phone' onChange={data} />
      </div>
      <div className={STYLE.formitems}>
          <label htmlFor="dob">DOB</label>
          <input type="date" id='dob' name='dob' onChange={data} />
      </div>
      <label htmlFor="gender">Gender</label>
      <div className={STYLE.formitems} id={STYLE.gender}>
          <div>
              Male: <input type="radio" name='gender' value={"male"} onChange={data} />
          </div>
          <div>
              Female: <input type="radio" name='gender' value={"female"} onChange={data} />
          </div>
      </div>
      <button className={STYLE.register}>Register</button>
      </form>
      </div>
)
}


export default Addaccmanager;