import React from 'react'

const Viewbranch = () => {
  return (
    <div>Viewbranch</div>
  )
}

export default Viewbranch