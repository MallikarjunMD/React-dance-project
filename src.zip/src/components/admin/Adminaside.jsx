import React from 'react'
import { Link } from 'react-router-dom'
import STYLE from "./dashboard.module.css"

const Adminaside = () => {
  return (
    <div className={STYLE.adminaside}>
        <h3>ADMIN DASHBOARD</h3>
        <ul>
            <li>
                <Link to={"/dashboard/addaccmanager"}>ADD ACCADEMY</Link>
            </li>
            <li>
                <Link to={"/dashboard/viewmanager"}>VIEW MANAGER</Link>
            </li>
            <li>
                <Link to={"/dashboard/viewaccademy"}>VIEW ACADEMY</Link>
            </li>
            <li>
                <Link to={"/dashboard/viewbranch"}>VIEW BRANCH</Link>
            </li>
            <li>
                <Link to={"/dashboard/viewcourse"}>VIEW COURSE</Link>
            </li>
        </ul>
    </div>
  )
}

export default Adminaside;