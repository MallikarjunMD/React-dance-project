import React from 'react'

const Pagenotfound = () => {
  return (
    <div style={{height:"100vh",width:"100vw"}}>

        <img  height={"100%"} width={"100%"} src="https://miro.medium.com/v2/resize:fit:1358/0*QOZm9X5er1Y0r5-t" alt="" />
        </div>
  )
}

export default Pagenotfound;