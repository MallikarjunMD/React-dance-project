import React from 'react'
import Video from "../../../src/assets/Video.mp4"
import STYLE from "./home.module.css"

const Home = () => {
  return (
    <div className={STYLE.home}>
      <h2>home</h2>
      <video src={Video} muted autoPlay loop></video> 
    </div>
  )
}

export default Home