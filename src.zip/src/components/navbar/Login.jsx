import React,{useState} from 'react'
import STYLE from "./login.module.css"
import axiosInstance from "../../helpers/axiosInstance"
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'


const Login = () => {
  let navigate=useNavigate()
  let[toggle,setToggle]=useState(false)
  let passIcon=()=>{
    if(toggle){
      setToggle(false)
    }
    else{
      setToggle(true)
    }
  }
  let[userAuth,setUserAuth]=useState({
    userEmail:"",
    password:""

  })

  let handleLogin=async (e)=>{
    e.preventDefault()
    try {
      let payload=userAuth;
      let{data}=await axiosInstance.post("/authenticate",payload)
      sessionStorage.setItem("token",data.token)
      sessionStorage.setItem("role",data.role)
      sessionStorage.setItem("useremail",userAuth.userEmail)
      toast.success(`${userAuth.userEmail} logged in`)
      window.location.assign("/")
    } catch (error) {
      toast.error("Invalid credentials!")
    }
  }
  return (
    <div className={STYLE.formholder}>
        <form action="" className={STYLE.form} onSubmit={handleLogin}>
            <h2>Login</h2>
            <div className={STYLE.formitem}>
                <label htmlFor="useremail">Email</label>
                <input type="email" id='useremail' name='userEmail' onChange={(e)=>{
                  setUserAuth({...userAuth,[e.target.name]:e.target.value})
                }} />
            </div>
            <div className={STYLE.formitem}>
                <label htmlFor="password">Password</label>
                <div className={STYLE.icon}>
                <input type={toggle ? "text" : "password"} id='password' name='password' onChange={(e)=>{
                  setUserAuth({...userAuth,[e.target.name]:e.target.value})
                }}/>
                {toggle?<img onClick={passIcon} src='https://www.freeiconspng.com/thumbs/eye-icon/eyeball-icon-png-eye-icon-1.png'/> : 
                
                <img onClick={passIcon} src='https://cdn.iconscout.com/icon/free/png-256/free-eye-slash-3604201-3003511.png'/>}
            </div>
            </div>
            <button className={STYLE.login}>LOGIN</button>
        </form>
    </div>
  )
}

export default Login